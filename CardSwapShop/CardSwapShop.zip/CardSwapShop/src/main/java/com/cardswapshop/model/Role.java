package com.cardswapshop.model;

public enum Role {
    USER,
    ADMIN
}
