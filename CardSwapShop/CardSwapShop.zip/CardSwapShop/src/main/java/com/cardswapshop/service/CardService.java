package com.cardswapshop.service;

import com.cardswapshop.model.Card;
import com.cardswapshop.repository.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CardService {

    private CardRepository cardRepository;

    public CardService() {
    }

    @Autowired
    public CardService(CardRepository cardRepository) {
        this.cardRepository = cardRepository;
    }

    public List<Card> findAll() {
        return cardRepository.findAll();
    }

    public Optional<Card> findById(Long id) {
        return cardRepository.findById(id);
    }

    public void save(Card card){
        cardRepository.save(card);
    }

    public void delete(Long id) {
        cardRepository.deleteById(id);
    }

    public void update(Card card) {
        cardRepository.save(card);
    }


    public List<Card> findByCollectionId(Long id) {
        return cardRepository.findByCollectionId(id);
    }

    public List<Card> findByName(String title) {
        return cardRepository.findByNameAllIgnoreCase(title);
    }
}
